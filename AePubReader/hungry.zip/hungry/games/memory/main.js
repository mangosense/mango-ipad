var MangoGame = {
    init: function (options) {
        if (options.from_mobile)
            var root_path = '../../';
        else
            var root_path = options.story_path;
        var str='';
        $(options.images).each(function(key){

            str=str+'<li class="match'+key+'"><img src="'+root_path+options.images[key]+'"></li>';
            str=str+'<li class="match'+key+'"><img src="'+root_path+options.images[key]+'"></li>';
        });

        $('#memory_container').append('<div id="tutorial-memorygame" class="quizy-memorygame" style="width:742px"><ul>' + str + '</ul></div>');


        $('#tutorial-memorygame').quizyMemoryGame({
            itemWidth : 120,
            itemHeight : 120,
            itemsMargin : 40,
            colCount : 4,
            animType : 'flip',
            flipAnim : 'tb',
            animSpeed : 250,
            resultIcons : false,
            openDelay : 1250,
            gameSummary : false,
            onFinishCall : function(param) {
                $('#time').text(param.time);
                $("#sucess_popup_id").bPopup({
                    zIndex : 999999
                });
                var fsharebutton = 'https://www.facebook.com/dialog/feed?app_id=344525655596295&link=http://www.mangoreader.com/store&picture=http://www.mangoreader.com/assets/Game-score-share2.jpg&name=Hurray..!!&caption=Hurray!%20I%20have%20finished%20the%20game%20in%20' + param.time + '%20Seconds%20on%20MangoReader%20Book-%20We%20bring%20Books%20to%20Life&redirect_uri=http://www.mangoreader.com';

                $('#fsharebutton').click(function() {
                    window.open(fsharebutton);
                });

            }
        });

    }

}