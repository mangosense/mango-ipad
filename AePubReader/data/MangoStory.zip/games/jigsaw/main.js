var MangoGame = {
	init: function (options) {
		if (options.from_mobile){
			var imagePath = '../../'+options.url;
		}
		else{
			story_id = options.story_path .substring(9,33)
			var imagePath = '/live_stories/'+story_id + "/"+ options.url;
		}
		$('#puzzle_pic_id').attr('src',imagePath);
	}

}
var clickedId;
var rTime;
var _StopWatch = new StopWatch();

function mixup() {
	snapfit.add(document.getElementById('puzzle_pic_id'),
		{callback: function()
		{
			_StopWatch.stop();
			time=_StopWatch.duration();
			$('#time').text(time);
			/*			new Messi('You have completed the Game in '+_StopWatch.duration()+' seconds.', {
			 title : 'Hurraay...!!',
			 zIndex:999999,
			 titleClass : 'info',
			 buttons : [{
			 id : 0,
			 label : 'Close',
			 val : 'X'
			 }]
			 });
			 */
			var fsharebutton = 'https://www.facebook.com/dialog/feed?app_id=344525655596295&link=http://www.mangoreader.com/store&picture=http://www.mangoreader.com/assets/Game-score-share2.jpg&name=Hurray..!!&caption=Hurray!%20I%20have%20finished%20the%20game%20in%20'+time+'%20Seconds%20on%20MangoReader%20Book-%20We%20bring%20Books%20to%20Life&redirect_uri=http://www.mangoreader.com';

			$("#sucess_popup_id").bPopup({
				zIndex:999999
			});


			$('#fsharebutton').click(function() {
				window.open(fsharebutton);
			});



		},

			aimage : true,
			mixed : true,
			simple : true,
			polygon : true,
			level :1,
			space : 10
		});

}

$("#start_game").click(function(){
	mixup();
	_StopWatch.start();
	$(".start_game").hide();
	clickedId= $("#puzzle_pic_id").attr("id");
});

$(".easy-button").click(function(){
	mixup_easy(clickedId);
});

$(".medium-button").click(function(){
	mixup_medium(clickedId);
});

$(".hard-button").click(function(){
	mixup_hard(clickedId);
});

$(".solution-button").click(function(){
	solution(clickedId);
});

$("#back-button").click(function(){
	$('#game_container').toggle("clip",500);
	$(".jp-play").click();
});

function mixup_easy(clickedId){
	snapfit.reset(document.getElementById(clickedId),1);
	snapfit.admix(document.getElementById(clickedId),true);
}

function mixup_medium(clickedId){
	snapfit.reset(document.getElementById(clickedId),2);
	snapfit.admix(document.getElementById(clickedId),true);
}

function mixup_hard(clickedId){
	snapfit.reset(document.getElementById(clickedId),3);
	snapfit.admix(document.getElementById(clickedId),true);
}

function solution(clickedId)
{
	snapfit.solve(document.getElementById(clickedId));
}