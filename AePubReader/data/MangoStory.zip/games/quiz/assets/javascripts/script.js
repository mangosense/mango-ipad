var MangoGame = {
	init: function(data) {

		var quizWrapper = $('<div class="quizWrapper selectable">');
		var quizContainter = $('<div id="quiz-container">');
		var quizQuestions, comment, scriptText;

		quizWrapper.append(quizContainter);

		$('body').html(quizWrapper);
		title = '<div class="title">Quiz</div>';
		quizWrapper.prepend(title);

		quizQuestions = "var quizQuestions = [";

		for (var attr in data) {
			if (attr.indexOf('set-') == 0)
				quizQuestions += JSON.stringify(data[attr]) + ","

		}
		//to remove the last comma character from string
		quizQuestions = quizQuestions.slice(0, -1)
		quizQuestions += "];";
		comment = "var resultcomment = { perfect: 'Outstanding..100%', excellent: 'Impressive..!', good: 'Exceeds expectations!', average: 'Acceptable. You can do better.', bad: 'You need to try a bit harder.', poor: 'Dreadful!', worst: 'You need practice..!' };";
		scriptText = quizQuestions + comment + "$('#quiz-container').jquizzy({ questions: quizQuestions, resultComments: resultcomment });";

		if ($('body').find("#quizscript").length < 1) {
			var script = document.createElement("script");
			script.type = "text/javascript";
			script.id = "quizscript";
			script.text = scriptText;
			$('body').append(script);
		}
	}

}