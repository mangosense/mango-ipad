var html = '';
var dataArray = new Array(); //will hold the question and asnwer as inputted by the teacher
var answerArray = new Array(); //will hold the answer as entered by the child/user
var userInput;
var tempJSON;
var correctAnswer = "B";

function gameInteractive() {
	this.counter = 1;
}
gameInteractive.prototype.init = function() {

	$("#optionOne").click(function() {
		userInput = $(this).attr('data-option'); //captures the user input
		dataArray.length = 0; //flushes the array in case of multiple clicks
		dataArray.push("{'userAnswer=" + userInput + ",Correct Answer=" + correctAnswer + "}"); //pushes the data into the array
		tempJSON = JSON.stringify(dataArray); //stores the user response in JSON format
		mangoObj.getEndScreen(); //loads the end screen
	});

	$("#optionTwo").click(function() {
		userInput = $(this).attr('data-option'); //captures the user input
		dataArray.length = 0; //flushes the array in case of multiple clicks
		dataArray.push("{'userAnswer=" + userInput + ",Correct Answer=" + correctAnswer + "}"); //pushes the data into the array
		tempJSON = JSON.stringify(dataArray); //stores the user response in JSON format
		mangoObj.getEndScreen(); //loads the end screen
	});

	$(".hint").click(function() {
		$(".hintAnswer").fadeToggle('slow');
	});

	$(".closebar").click(function() {
		$(".hintAnswer").fadeOut('fast');
	});

	$(".hintAnswer").draggable({
		'containment': '#container'
	});
}
gameInteractive.prototype.getEndScreen = function() {
	html = '';
	html += '<div id="endScreen">';
	html += '<div class="endScreenText"><span class="endScreenText-text">Great..!!!</br>Your answer has been submitted..!!</span></div>';
	html += '</div>';
	$("#container").html(html);
}

function containerResize() {
	var scaleFactor = 1;
	var scaleFactor1 = 0;
	var scaleFactor2 = 0;
	if (window.innerHeight < $("#container").height()) {
		scaleFactor1 = parseFloat(window.innerHeight / $("#container").height());
	} else
		scaleFactor1 = 1;

	if (window.innerWidth < $("#container").width()) {
		scaleFactor2 = parseFloat(window.innerWidth / $("#container").width());
	} else
		scaleFactor2 = 1;

	if (scaleFactor1 < scaleFactor2)
		scaleFactor = scaleFactor1;
	else
		scaleFactor = scaleFactor2;
	$("#container").css({
		"-webkit-transform": "scale(" + scaleFactor + ")"
	});
	$("#container").css({
		"-moz-transform": "scale(" + scaleFactor + ")"
	});
	$("#container").css({
		"-o-transform": "scale(" + scaleFactor + ")"
	});
	$("#container").css({
		"-ms-transform": "scale(" + scaleFactor + ")"
	});
	$("#container").css({
		"transform": "scale(" + scaleFactor + ")"
	});
}