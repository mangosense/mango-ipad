var data;
var userInput = '';
var dataArray = '';
var answerArray = '';
var correctAnswer = '';
var tempJSON = '';
var html = '';
var correctOption = '';
var option1;
var option2;
var MangoGame = {
	init: function(data) {
		option1 = data.option1;
		option2 = data.option2;
		//This function would be called at the time when game is added on to the page and woulb be
		//automatically initialized

		$(".questionText").html(data.question); //inserts the question into DOM class questionText
		$("#option1").html(data.option1); //inserts the option1 into DOM id option1
		$("#option2").html(data.option2); //inserts the option2 into DOM id option2
		$("#helpText").html(data.hintAnswer); //inserts the hint answer into DOM id helpText

		$("#one").on('click', function() {

			dataArray = new Array(); //will hold the question and asnwer as inputted by the teacher
			answerArray = new Array(); //will hold the answer as entered by the child/user
			correctAnswer = data.correctAnswer;
			userInput = $(this).attr('data-option'); //captures the user input

			dataArray.length = 0; //flushes the array in case of multiple clicks
			dataArray.push("{'userAnswer=" + userInput + ",Correct Answer=" + correctAnswer + "}"); //pushes the data into the array
			tempJSON = JSON.stringify(dataArray); //stores the user response in JSON format

			MangoGame.endScreen(); // on submission of the answer End Screen would be loaded

		});

		$("#two").on('click', function() {

			dataArray = new Array(); //will hold the question and asnwer as inputted by the teacher
			answerArray = new Array(); //will hold the answer as entered by the child/user
			userInput = $(this).attr('data-option'); //captures the user input
			correctAnswer = data.correctAnswer;
			dataArray.length = 0; //flushes the array in case of multiple clicks
			dataArray.push("{'userAnswer=" + userInput + ",Correct Answer=" + correctAnswer + "}"); //pushes the data into the array
			tempJSON = JSON.stringify(dataArray); //stores the user response in JSON format

			MangoGame.endScreen(); // on submission of the answer End Screen would be loaded
		});

		$(".hint").on('click', function() {
			$(".hintAnswer").fadeToggle('slow');
		});

		$(".closebar").on('click', function() {
			$(".hintAnswer").fadeOut('fast');
		});

		$(".hintAnswer").draggable({
			'containment': '#container'
		});

	}, //end of init

	endScreen: function() {

		if (correctAnswer == 1) {
			var show = option1;
		} else if (correctAnswer == 2) {
			var show = option2;
		}
		if (correctAnswer == userInput) {
			html = '';
			html += '<div id="endScreen">';
			html += '<div class="endScreenText">';
			html += '<span class="endScreenText-text">Great..!!!</br>Your answer is correct..!!!</span>';
			html += '<span class="showAnswerBlock">' + show + '</span>'
			html += '</div>';
			html += '</div>';

			$("#container").html(html);
		} else {
			html += '<div id="endScreen">';
			html += '<div class="endScreenText">';
			html += '<span class="endScreenText-text">Oops..!! You marked the wrong answer.</span>';
			html += '<span class="showAnswerBlock"><strong>Correct Answer : </strong>' + show + '</span>'
			html += '</div>';
			html += '</div>';
			$("#container").html(html);
		}
	}
}