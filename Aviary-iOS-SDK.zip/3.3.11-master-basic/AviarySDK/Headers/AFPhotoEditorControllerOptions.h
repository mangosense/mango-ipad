//
//  AFPhotoEditorControllerOptions.h
//  AviarySDK
//
//  Copyright (c) 2012 Aviary, Inc. All rights reserved.
//

/**
 This class has been replaced by AFPhotoEditorCustomization in 2.5.0. Please use AFPhotoEditorCustomization instead.
 */
#import "AFPhotoEditorCustomization.h"
